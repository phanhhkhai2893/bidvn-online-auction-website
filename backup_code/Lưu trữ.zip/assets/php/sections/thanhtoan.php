<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán - BIDVN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* Định nghĩa biến màu sắc (Tiếp nối từ Giỏ Hàng) */
        :root {
            --color-primary-light: #FFD54F; /* Vàng nhạt */
            --color-primary-dark: #FBC02D;  /* Vàng đậm cho button */
            --color-bg-light: #fdfdfd;      /* Nền trắng nhẹ */
            --color-text-dark: #333333;
            --color-text-muted: #777777;
            --color-border: #e0e0e0;
            --shadow-soft: 0 8px 24px rgba(0, 0, 0, 0.1);
            --border-radius: 12px;
            --color-success: #4CAF50;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f4f4; /* Nền hơi xám để làm nổi bật khối trắng */
            color: var(--color-text-dark);
        }
        
        /* --- Top Bar --- */
        .top-bar {
            background-color: var(--color-primary-dark);
            color: white;
            padding: 15px 50px;
            text-align: center;
            font-size: 1.8em;
            font-weight: 700;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        /* --- Main Layout --- */
        .checkout-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
        }

        /* Layout 2 cột khi màn hình lớn hơn */
        @media (min-width: 992px) {
            .checkout-container {
                grid-template-columns: 3fr 2fr; /* Form chiếm 3/5, Tóm tắt chiếm 2/5 */
            }
        }

        /* --- Card Styles (Khối nổi) --- */
        .checkout-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-soft);
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .checkout-card h2 {
            font-size: 1.6em;
            color: var(--color-text-dark);
            margin-bottom: 20px;
            border-bottom: 2px solid var(--color-border);
            padding-bottom: 10px;
        }

        /* --- Form Styles --- */
        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--color-text-dark);
        }

        input[type="text"], input[type="email"], input[type="tel"], select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--color-border);
            border-radius: 8px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input:focus, select:focus {
            border-color: var(--color-primary-dark);
            outline: none;
        }
        
        /* --- Payment/Summary Styles --- */
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px dashed var(--color-border);
            font-size: 1em;
        }
        
        .summary-item:last-of-type {
            border-bottom: none;
            margin-bottom: 15px;
        }

        .summary-item.total {
            font-size: 1.4em;
            font-weight: 700;
            color: var(--color-primary-dark);
            padding-top: 15px;
            border-top: 2px solid var(--color-primary-light);
        }

        /* Phương thức thanh toán */
        .payment-option {
            background-color: #f9f9f9;
            border: 1px solid var(--color-border);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: border-color 0.2s;
            display: flex;
            align-items: center;
        }
        
        .payment-option.selected {
            border-color: var(--color-primary-dark);
            box-shadow: 0 0 5px rgba(251, 192, 45, 0.5);
        }

        .payment-option i {
            margin-right: 10px;
            color: var(--color-primary-dark);
        }

        /* Nút hoàn tất */
        .complete-checkout-btn {
            display: block;
            width: 100%;
            padding: 15px;
            background-color: var(--color-success); /* Dùng màu xanh lá cây cho hành động cuối cùng */
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.3em;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            margin-top: 20px;
        }
        
        .complete-checkout-btn:hover {
            background-color: #43A047;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
	<?PHP
	
		$query = "SELECT * FROM nguoi_dung WHERE MaND = '$MaND_real'";
		$result = mysqli_query($kn -> con, $query)
		  or die("Lỗi DTB");
		$row = mysqli_fetch_array($result);
	?>
    <div class="checkout-container">
        
        <div>
            <div class="checkout-card">
                <h2><i class="fas fa-user-circle"></i> Thông Tin Liên Hệ</h2>
                <form action="#" method="POST">
                    <div class="form-group">
                        <label for="name">Họ và Tên (*)</label>
                        <input type="text" id="name" name="name" value="<?PHP echo $tennd; ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email (*)</label>
                        <input type="email" id="email" name="email" value="<?PHP echo $row['email']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="phone">Số Điện Thoại (*)</label>
                        <input type="tel" id="phone" name="phone" value="<?PHP echo $row['sdt']; ?>">
                    </div>
            </div>

            <div class="checkout-card">
                <h2><i class="fas fa-map-marker-alt"></i> Địa Chỉ Giao Hàng</h2>
                
                    <div class="form-group">
                        <label for="address">Địa chỉ chi tiết (*)</label>
                        <input type="text" id="address" name="address" value="<?PHP echo $row['diachi']; ?>" required/>
                    </div>
                    <div class="form-group">
                        <label for="city">Tỉnh/Thành phố (*)</label>
                        <select id="city" name="city" required>
                            <option value="">Chọn Tỉnh/Thành phố</option>
                            <option value="HCM">TP. Hồ Chí Minh</option>
                            <option value="HN">Hà Nội</option>
                            <option value="AG">An Giang</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="notes">Ghi chú (Tùy chọn)</label>
                        <input type="text" id="notes" name="notes" placeholder="Ví dụ: Giao ngoài giờ hành chính">
                    </div>
            </div>
        </div>

        <div>
            <div class="checkout-card">
                <h2><i class="fas fa-credit-card"></i> Phương Thức Thanh Toán</h2>
                
                <div class="payment-option selected" id="cod">
                    <i class="fas fa-money-bill-wave"></i>
                    Thanh toán khi nhận hàng (COD)
                </div>
                
                <div class="payment-option" id="bank-transfer">
                    <i class="fas fa-university"></i>
                    Chuyển khoản Ngân hàng
                </div>
                
                <div class="payment-option" id="e-wallet">
                    <i class="fas fa-wallet"></i>
                    Ví điện tử (Momo, ZaloPay...)
                </div>
                
            </div>
            
            <div class="checkout-card">
                <h2><i class="fas fa-receipt"></i> Tóm Tắt Đơn Hàng</h2>
                
                <div class="summary-item">
                    <span>Tổng tiền sản phẩm (3)</span>
					<?PHP
						if (isset($_GET['tt']))
						{
							$thanhtien = $_GET['tt'];
						}
					?>
                    <span><?PHP echo $thanhtien; ?></span>
                </div>
                <div class="summary-item">
                    <span>Phí vận chuyển</span>
                    <span style="color: var(--color-success);">Miễn phí</span>
                </div>
                
                <div class="summary-item total">
                    <span>Tổng Thanh Toán</span>
                    <span><?PHP echo $thanhtien; ?></span>
                </div>
                
                <p style="font-size: 0.9em; color: var(--color-text-muted); text-align: center;">Bằng việc nhấn nút, bạn đồng ý với các điều khoản của BIDVN.</p>
                <form action="" method="post">
                	<button type="submit" name="thanhtoan" class="complete-checkout-btn">HOÀN TẤT ĐẶT HÀNG</button>
				</form>
            </div>
        </div>
    </form>
    </div>
	
	<?PHP
		if (isset($_POST['thanhtoan']))
		{
			$query = "SELECT SoHD, CAST(REPLACE(SoHD, 'HD', '') AS SIGNED) AS ma_so FROM hoa_don ORDER BY ma_so DESC LIMIT 1";

			// Thực hiện truy vấn (Giả định $kn->con là đối tượng kết nối mysqli)
			$result = mysqli_query($kn->con, $query);

			if ($result && mysqli_num_rows($result) > 0) {
				$row = mysqli_fetch_assoc($result);
				$lastMa = $row['SoHD']; 

				$lastNumber = (int) str_replace('HD', '', $lastMa);

				$newNumber = $lastNumber + 1; 

			} else {
				$newNumber = 1; 
			}

			$newMa = 'HD' . $newNumber;
			$noidung = "Thanh toán";
			
			date_default_timezone_set('Asia/Ho_Chi_Minh'); 
			$ngay_dang_ky_hien_tai = date('Y-m-d H:i:s');
			$pttt = "";
			
			$tensp_safe = mysqli_real_escape_string($kn->con, $_POST['tensp']);
			
			$query = "INSERT INTO `hoa_don` (
				`MaSP`, 
				`tensp`, 
				`mota`, 
				`gia_khoidiem`, 
				`gia_hientai`, 
				`buocgia`, 
				`thoigian_batdau`, 
				`thoigian_ketthuc`, 
				`trangthai`,
				`MaDSHA`, 
				`MaND`, 
				`MaDM`, 
				`MaDMCon`
			) VALUES (
				'$masp', 
				N'$tensp_safe', 
				N'$mota_safe', 
				'$gia_khoidiem_safe', 
				'$gia_hientai_safe', 
				'$buocgia_safe', 
				'$thoigian_batdau_safe', 
				'$thoigian_ketthuc_safe', 
				N'$trangthai_safe',
				'$madsha_safe', 
				'$mand_safe', 
				'$madm_safe', 
				'$madmcon_safe'
			)";
//echo $query;
			$result = mysqli_query($kn->con, $query)
				or die("Lỗi DTB: " . mysqli_error($kn->con)); // Nên hiển thị lỗi chi tiết để debug

			if ($result) {
				// Chuyển hướng về trang chính sau khi thêm thành công
				echo "<meta http-equiv='refresh' content='0; url=admin_index.php' />";
			} else {
				// In ra lỗi chi tiết nếu không chuyển hướng được
				echo "Lỗi chèn dữ liệu: " . mysqli_error($kn->con);
			}
		}
	?>

    <script>
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                // Xóa trạng thái selected khỏi tất cả
                document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
                // Thêm trạng thái selected cho tùy chọn hiện tại
                this.classList.add('selected');
            });
        });
    </script>
</body>
</html>