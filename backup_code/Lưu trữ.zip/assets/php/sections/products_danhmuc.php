<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
      <div id="sanpham" class="product">
        <div class="product-header">
            <?PHP
              if (isset($_GET['madm']))
              {
                $madm = mysqli_real_escape_string($kn->con, $_GET['madm']);
                $query = "SELECT * FROM danh_muc WHERE MaDM = '$madm'";
                $result = mysqli_query($kn -> con, $query)
                  or die("Lỗi DTB");
                $row = mysqli_fetch_array($result);
            ?>
          <h3 href="#" class="header-link active">Các sản phẩm <?php echo $row['tendm']; ?></h3>
        </div>

        <div class="product-list-container">
          <div class="product-grid">
            <?PHP
                $query = "SELECT * FROM (san_pham INNER JOIN nguoi_dung ON san_pham.MaND = nguoi_dung.MaND) INNER JOIN danh_sach_hinh_anh ON san_pham.MaDSHA = danh_sach_hinh_anh.MaDSHA WHERE MaDM = '$madm' GROUP BY san_pham.MaSP";
                $result = mysqli_query($kn -> con, $query)
                  or die("Lỗi DTB");
                while ($row = mysqli_fetch_array($result))
                {
            ?>
                <a href="sanpham_detail.php?masp=<?PHP echo $row['MaSP']; ?>" class="product-item">
                  <img class="image-placeholder" src="assets/imgs/product/<?PHP echo $row['MaDSHA']; ?>/<?PHP echo $row['hinhanh']; ?>" alt="" />
                  
                  <div class="product-info">
                      <h3 class="product-name"><?PHP echo $row['tensp']; ?></h3>
                      <p class="product-des"><?PHP if (strlen($row['mota']) > 25) echo substr($row['mota'], 0, 25) . "..."; else echo $row['mota']; ?></p>
                      <p class="product-price"><?PHP echo number_format($row['gia_hientai'], 0, '', '.') . "đ"; ?></p>
                      <div class="product-footer">
                          <span class="location">
                              <span class="material-icons"><i class="fa fa-user" aria-hidden="true"></i></span>&nbsp; <?PHP echo $row['hoten'] ?>
                          </span>
                      </div>
                  </div>
                </a>
            <?PHP
                }
              }
            ?>
          </div>
        </div>
      </div>
</body>
</html>