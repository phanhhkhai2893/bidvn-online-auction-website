<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<footer id="lienhe" class="footer">
    <div class="container">
      <div class="footer-container">
        <div class="footer-col customer-support">
            <h4 class="col-title">Hỗ trợ khách hàng</h4>
            <ul class="link-list">
                <li><a href="#">Trung tâm trợ giúp</a></li>
                <li><a href="#">An toàn mua bán</a></li>
                <li><a href="#">Liên hệ hỗ trợ</a></li>
            </ul>
        </div>

        <div class="footer-col about-us">
            <h4 class="col-title">Về BIDVN</h4>
            <ul class="link-list">
                <li><a href="#">Giới thiệu</a></li>
                <li><a href="#">Quy chế hoạt động sàn</a></li>
                <li><a href="#">Chính sách bảo mật</a></li>
                <li><a href="#">Giải quyết tranh chấp</a></li>
                <li><a href="#">Tuyển dụng</a></li>
                <li><a href="#">Truyền thông</a></li>
                <li><a href="#">Blog</a></li>
            </ul>
        </div>

        <div class="footer-col contact-info">
            <h4 class="col-title">Liên kết</h4>
            
            <div class="social-links">
                <a href="#" class="social-icon linkedin"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" class="social-icon facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-icon youtube"><i class="fab fa-youtube"></i></a>
            </div>

            <p class="contact-detail">Email: info@bidvn.vn</p>
            <p class="contact-detail">CSKH: 19001900</p>
            <p class="address-detail">
                Địa chỉ: Đường Trần Hưng Đạo, Phường Mỹ Thới, Tỉnh An Giang, Việt Nam
            </p>
        </div>
      </div>
    </div>  
  </footer>
</body>
</html>