<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	
	<div id="toast-ui-container" class="toast-ui-container"></div>
<div id="auth-modal" class="modal hidden">
    <div class="modal-content">
        <span id="close-modal" class="close-btn">&times;</span>

        <form method="post" id="login-form" class="auth-form hidden">
            <h2>Đăng nhập</h2>
			<div id="login-error-message" class="error-box hidden">
				<i class="fa fa-exclamation-triangle" aria-hidden="true"></i><p>Tên đăng nhập hoặc mật khẩu chưa đúng, vui lòng kiểm tra lại!</p>
			</div>
            <label for="login-email">Tên đăng nhập:</label>
            <input name='tenDN' class="" type="text" id="login-email" required>
            <label for="login-password">Mật khẩu:</label>
            <input name='pass' type="password" id="login-password" required>
            <button id="signinBtn" name='dangnhap' type="submit" >Đăng nhập</button>
			<div class="separator-text">
				<span>Hoặc</span>
			</div>
            <button onClick="openModal('register');" name='' class="signup-btn" type="button" >Đăng ký</button>
        </form>

        <form method="post" id="register-form" class="auth-form hidden">
            <h2>Đăng ký tài khoản mới</h2>
            <label for="register-name">Họ tên:</label>
            <input type="text" name="dk-hoten" id="register-name" required>
            <label for="register-email">Username:</label>
            <input type="text" name="dk-usn" id="register-email" required>
            <label for="register-role">Bạn là...?</label>
            <input type="radio" name="dk-role" id="register-role" value="Người bán" checked> Người bán
            <input type="radio" name="dk-role" id="register-role" value="Người mua"> Người mua
            <label for="register-password">Mật khẩu:</label>
            <input type="password" name="dk-pass" id="register-password" required>
            <label for="register-password">Xác nhận mật khẩu:</label>
            <input type="password" name="dk-confirm-pass" id="" required>
            <button name="dangky" type="submit">Đăng ký</button>
			<div class="separator-text">
				<span>Hoặc</span>
			</div>
            <button onClick="openModal('login');" name='' class="signup-btn" type="button" >Đăng nhập</button>
        </form>
    </div>
</div>
<script type="text/javascript" src="assets/js/dangnhap.js"></script>
<script>
	function showToast(message, type = 'info', duration = 3000) {
			const container = document.getElementById('toast-ui-container');
			if (!container) return;

			// 1. Tạo phần tử Toast
			const toast = document.createElement('div');
			toast.classList.add('toast-ui-message', `toast-ui-${type}`);

			// Chọn icon dựa trên loại
			let iconClass = '';
			switch(type) {
				case 'success':
					iconClass = 'fas fa-check-circle';
					break;
				case 'error':
					iconClass = 'fas fa-times-circle';
					break;
				case 'warning':
					iconClass = 'fas fa-exclamation-triangle';
					break;
				case 'info':
				default:
					iconClass = 'fas fa-info-circle';
					break;
			}

			// Thêm icon và nội dung
			toast.innerHTML = `<i class="${iconClass}"></i> ${message}`;

			// 2. Thêm vào container và hiển thị
			container.appendChild(toast);

			// Sử dụng setTimeout để đảm bảo transition hoạt động
			setTimeout(() => {
				toast.classList.add('show');
			}, 10);

			// 3. Tự động xóa sau duration
			const hideTimeout = setTimeout(() => {
				// Bắt đầu hiệu ứng ẩn
				toast.classList.remove('show');

				// Đợi transition kết thúc rồi xóa khỏi DOM
				toast.addEventListener('transitionend', () => {
					toast.remove();
				});

			}, duration);

			// Tùy chọn: Xóa toast khi click vào
			toast.addEventListener('click', () => {
				clearTimeout(hideTimeout);
				toast.classList.remove('show');
				toast.addEventListener('transitionend', () => {
					toast.remove();
				});
			});
		}
</script>
<?PHP
	
	if (isset($_POST['dangnhap'])) {
		$ten = $_POST['tenDN'];
		$mk = $_POST['pass'];
		$sql = "SELECT * FROM nguoi_dung WHERE username = '$ten' AND password = '$mk'";
		$tbltk = $kn->truyvan_sql($sql);
		if ($tbltk && mysqli_num_rows($tbltk) > 0)
		{
			$user = mysqli_fetch_assoc($tbltk);
			$_SESSION['role'] = $user['phanquyen'];
			$_SESSION['tennd'] = $user['hoten'];
			$_SESSION['mand'] = $user['MaND'];
			unset($_SESSION['SignInError']);
		?>
		<?PHP
			echo "<meta http-equiv='refresh' content='0; url=index.php' />";
			echo '<script type="text/javascript">';
			echo "	errorMsg.classList.remove('hidden');";
			echo '</script>';
		}
		else 
		{
			$_SESSION['tennd'] = $ten;
			$_SESSION['SignInError'] = true;
		}
	}
	
	if (isset($_POST['dangky'])) {
		$sql = "SELECT * FROM nguoi_dung";
		$tbltk = $kn->truyvan_sql($sql);
		if ($tbltk && mysqli_num_rows($tbltk) > 0)
		{
			$mand = "ND" . (mysqli_num_rows($tbltk) + 1);
		}
		
		$ten = $_POST['dk-hoten'];
		$usn = $_POST['dk-usn'];
		$role = $_POST['dk-role'];
		$mk = $_POST['dk-pass'];
		$cfmk = $_POST['dk-confirm-pass'];
		date_default_timezone_set('Asia/Ho_Chi_Minh'); 
		$ngaydk = date('Y-m-d H:i:s');
		if ($mk == $cfmk)
		{
			$sql = "
				INSERT INTO `nguoi_dung` 
				(
					MaND,
					username, 
					password, 
					hoten,
					email,
					sdt,
					diachi,
					avarta,
					phanquyen,
					ngaydangky,
					trangthai
				)
				VALUES
				(
					'$mand',
					'$usn',
					'$mk',
					'$ten',
					'',
					'',
					'',
					'',
					'$role',
					'$ngaydk',
					''
				);
			";
//			echo $sql;
			$result = mysqli_query($kn -> con, $sql)
			  or die("Lỗi DTB");

			if ($result) {
				echo "<meta http-equiv='refresh' content='0; url=index.php' />";
				echo "<script>";
				echo "	openModal('login');";
				echo "</script>";
			} 
			else {
				echo "Lỗi cập nhật dữ liệu: " . mysqli_error($kn -> con);
			}
		}
		
	}
?>
<script>
	
</script>
</body>
</html>