
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<div id="danhmuc" class="category-container">
        <div class="category-grid">
          <?PHP
            if (isset($_GET['madm']))
            {
              $madm = $_GET['madm'];
              $query = "SELECT * FROM danh_muc_con WHERE MaDM = '$madm' OR MaDMCon = '$madm'";
              $result = mysqli_query($kn -> con, $query)
                or die("Lỗi DTB");
              while ($row = mysqli_fetch_array($result))
              {
                $ma = $row['MaDMCon'];
          ?>
              <a href="sanpham_danhmuccon.php?madm=<?PHP echo $ma; ?>" class="category-item">
                 <div class="icon-placeholder">
                  <img src="assets/imgs/sub-category/<?PHP echo $row['hinhanh']; ?>" alt="<?PHP echo $row['tendm']; ?>" />
                 </div>
                  <p class="category-name"> 
                    <?PHP 
                      echo $row['tendm'];
                    ?>
                  </p>
              </a>
          <?PHP
              }
            }
          ?>
        </div>
                  <img src="../../imgs/sub-category/brand_gigabyte.png" alt="" />
      </div>
</body>
</html>