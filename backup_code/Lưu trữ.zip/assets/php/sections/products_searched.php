<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
<div id="sanpham" class="product">
	<div class="product-header">
		<?PHP
		  if (isset($_GET['keyword']) && $_GET['keyword'] != null)
			{
				$key = mysqli_real_escape_string($kn->con, $_GET['keyword']);
				$search_term = "%" . $key . "%";
		?>
	  <h3 href="#" class="header-link active">Kết quả tìm kiếm cho <?php echo $key; ?></h3>
	</div>

	<div class="product-list-container">
	  <div class="product-grid">
		<?PHP
				$query = "SELECT 
							sp.MaSP as 'masp',
							sp.MaDSHA as 'madsha',
							sp.tensp as 'tensp',
							sp.mota as 'mota',
							sp.gia_hientai as 'gia',
							dm.tendm as 'tendm',
							nd.hoten as 'hoten',
                            dsha.hinhanh as 'hinh'
						FROM 
							san_pham sp
						JOIN 
							danh_muc dm ON sp.MaDM = dm.MaDM
						JOIN
							nguoi_dung nd ON sp.MaND = nd.MaND
						JOIN
							danh_sach_hinh_anh dsha ON dsha.MaDSHA = sp.MaDSHA
						WHERE 
							sp.tensp LIKE '%$search_term%' 
							OR sp.mota LIKE '%$search_term%'
							OR dm.tendm LIKE '%$search_term%'
						GROUP BY sp.MaSP
						ORDER BY 
							sp.tensp DESC,
							sp.gia_hientai DESC";
				$result = mysqli_query($kn -> con, $query)
				  or die("Lỗi DTB");
				while ($row = mysqli_fetch_array($result))
				{
					?>
						<a href="sanpham_detail.php?masp=<?PHP echo $row['masp']; ?>" class="product-item">
						  <img class="image-placeholder" src="assets/imgs/product/<?PHP echo $row['madsha']; ?>/<?PHP echo $row['hinh']; ?>" alt="" />

						  <div class="product-info">
							  <h3 class="product-name"><?PHP echo $row['tensp']; ?></h3>
							  <p class="product-des">
								  <?PHP 
									if (strlen($row['mota']) > 25) 
										echo substr($row['mota'], 0, 25) . "..."; 
									else 
										echo $row['mota']; 
								  ?>
							  </p>
							  <p class="product-price"><?PHP echo number_format($row['gia'], 0, '', '.') . "đ"; ?></p>
							  <div class="product-footer">
								  <span class="location">
									  <span class="material-icons"><i class="fa fa-user" aria-hidden="true"></i></span>&nbsp; <?PHP echo $row['hoten'] ?>
								  </span>
							  </div>
						  </div>
						</a>
					<?PHP
				}
			}
		?>
	  </div>
	</div>
</div>
</body>
</html>