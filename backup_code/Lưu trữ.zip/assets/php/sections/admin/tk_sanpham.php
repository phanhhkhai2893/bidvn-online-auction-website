<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>
<?PHP
//	TỔNG SỐ SẢN PHẨM
	$query = "SELECT COUNT(*) AS tong FROM san_pham";

	$result = mysqli_query($kn->con, $query);

	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_assoc($result); 

		$tongSP = $row['tong']; 
	} else {
		$tongSP = 0;
	}

//	TỔNG SỐ SẢN PHẨM ĐANG ĐẤU GIÁ
	$query = "SELECT COUNT(*) AS tong 
			FROM san_pham
			WHERE trangthai = N'Đang đấu giá'";

	$result = mysqli_query($kn->con, $query);

	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_assoc($result); 

		$spDangDG = $row['tong']; 
	} else {
		$spDangDG = 0;
	}

//	TỔNG SỐ SẢN PHẨM ĐÃ KẾT THÚC
	$query = "SELECT COUNT(*) AS tong 
			FROM san_pham
			WHERE trangthai = N'Đã kết thúc'";

	$result = mysqli_query($kn->con, $query);

	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_assoc($result); 

		$spKT = $row['tong']; 
	} else {
		$spKT = 0;
	}

//	TỔNG SỐ DOANH THU
	$query = "SELECT SUM(thanhtien) AS tong 
			FROM chi_tiet_hoa_don";

	$result = mysqli_query($kn->con, $query);

	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_assoc($result); 

		$doanhthu = $row['tong']; 
	} else {
		$doanhthu = 0;
	}

//	BIỂU ĐỒ NGƯỜI DÙNG 3 THÁNG
	$query = "SELECT 
				DATE_FORMAT(ngaydangky, '%Y-%m') AS registration_month,
				COUNT(MaND) AS new_user_count
			FROM 
				nguoi_dung
			WHERE 
				ngaydangky >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
			GROUP BY 
				registration_month
			ORDER BY 
				registration_month ASC;";

	$result = mysqli_query($kn->con, $query);

	$labels = []; 
	$counts = []; 

	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$labels[] = $row['registration_month'];
			$counts[] = (int)$row['new_user_count'];
		}
	}

	$chart_data = [
		'labels' => $labels,
		'data' => $counts
	];

	$chart_data_json = json_encode($chart_data);

//	BIỂU ĐỒ TỈ LỆ THAM GIA ĐẤU GIÁ
	$query_ratio = "SELECT 
						COUNT(T1.MaND) AS total_users,
						COUNT(T2.MaND) AS total_bidders
					FROM 
						nguoi_dung T1
					LEFT JOIN 
						(SELECT DISTINCT MaND FROM lich_su_dau_gia) T2 
					ON 
						T1.MaND = T2.MaND";

	$result_ratio = mysqli_query($kn->con, $query_ratio);

	$row_ratio = mysqli_fetch_assoc($result_ratio);

	$total_users = (int)$row_ratio['total_users'];
	$total_bidders = (int)$row_ratio['total_bidders'];

	// Tính toán nhóm chưa đặt giá
	$non_bidders = $total_users - $total_bidders;

	// Chuẩn bị dữ liệu cho biểu đồ tròn (Doughnut Chart)
	$ratio_data = [
		'labels' => ['Người dùng tham gia', 'Người dùng không tham gia'],
		'data' => [$total_bidders, $non_bidders]
	];

	$ratio_data_json = json_encode($ratio_data);
?>
	<div id="main-content">
        <div class="kpi-cards-container">
            <div class="kpi-card">
                <div class="kpi-icon">
					<img src="assets/imgs/others/products.png" alt="">
				</div>
                <div class="kpi-details">
                    <div class="kpi-value"><?PHP echo $tongSP; ?></div>
                    <div class="kpi-label">Tổng số Sản phẩm</div>
                </div>
            </div>
            <div class="kpi-card active-users">
                <div class="kpi-icon">
					<img src="assets/imgs/others/auction.png" alt="">
				</div>
                <div class="kpi-details">
                    <div class="kpi-value"><?PHP echo $spDangDG; ?></div>
                    <div class="kpi-label">Đang đấu giá</div>
                </div>
            </div>
            <div class="kpi-card new-users">
                <div class="kpi-icon">
					<img src="assets/imgs/others/bid.png" alt="">
				</div>
                <div class="kpi-details">
                    <div class="kpi-value"><?PHP echo $spKT; ?></div>
                    <div class="kpi-label">Đã kết thúc</div>
                </div>
            </div>
            <div class="kpi-card bidder-users">
                <div class="kpi-icon">
					<img src="assets/imgs/others/profit-up.png" alt="">
				</div>
                <div class="kpi-details">
                    <div class="kpi-value"><?PHP echo number_format($doanhthu, 0, '', '.') . "đ" ?></div>
                    <div class="kpi-label">Doanh thu</div>
                </div>
            </div>
        </div>

        <div class="charts-container">
            <div class="chart-box small-chart">
                <h3 class="chart-title">Sản phẩm ưa chuộng</h3>
                <canvas id="participationChart" style="max-height: 350px;"></canvas>
            </div>
            <div class="chart-box small-chart">
                <h3 class="chart-title">Tỷ lệ trạng thái</h3>
                <canvas id="participationChart" style="max-height: 350px;"></canvas>
            </div>
        </div>

        <div class="detail-table-container">
            <h3 class="table-title">Thống kê sản phẩm giá cao nhất</h3>
            <table>
                <thead>
                    <tr>
                        <th>Hạng</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Giá Khởi Điểm</th>
                        <th>Giá Thắng Cuộc</th>
                        <th>Người Thắng</th>
                    </tr>
                </thead>
                <tbody>
					<?PHP
						$query = "SELECT sp.tensp as 'tensp', sp.gia_khoidiem as 'giakd', cthd.thanhtien as 'tt', nd.hoten as 'hoten'
								FROM san_pham sp, chi_tiet_hoa_don cthd, hoa_don h, nguoi_dung nd
								WHERE sp.MaSP = cthd.MaSP
								AND cthd.SoHD = h.SoHD
								AND h.MaND = nd.MaND
								ORDER BY cthd.thanhtien DESC
								LIMIT 5";
						$result = mysqli_query($kn -> con, $query)
						  or die("Lỗi DTB");
						$i = 0;
						while ($row = mysqli_fetch_array($result))
						{
							$i++;
					?>
							<tr>
								<td style="text-align: center"><?PHP echo $i; ?></td>
								<td><?PHP echo $row['tensp']; ?></td>
								<td><?PHP echo number_format($row['giakd'], 0, '', '.') . "đ" ?></td>
								<td><?PHP echo number_format($row['tt'], 0, '', '.') . "đ" ?></td>
								<td><?PHP echo $row['hoten']; ?></td>
							</tr>
					<?PHP
						}
					?>
                </tbody>
            </table>
        </div>

        <div class="detail-table-container">
            <h3 class="table-title">Thống kê sản phẩm có lượt đấu giá cao nhất</h3>
            <table>
                <thead>
                    <tr>
                        <th>Hạng</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Giá Thắng Cuộc</th>
                        <th>Tổng lượt đặt giá</th>
                        <th>Số người tham gia</th>
                    </tr>
                </thead>
                <tbody>
					<?PHP
						$query = "SELECT 
									sp.TenSP as 'tensp', 
									MAX(cthd.ThanhTien) AS 'GiaThangCuoc',
									COUNT(ls.MaSP) AS 'LuotDat', 
									COUNT(DISTINCT ls.MaND) AS 'NguoiThamGia'
								FROM 
									san_pham sp
								JOIN 
									lich_su_dau_gia ls ON ls.MaSP = sp.MaSP
								LEFT JOIN 
									chi_tiet_hoa_don cthd ON sp.MaSP = cthd.MaSP
								GROUP BY 
									sp.MaSP, sp.TenSP
								ORDER BY 
									LuotDat DESC
								LIMIT 5;";
						$result = mysqli_query($kn -> con, $query)
						  or die("Lỗi DTB");
						$i = 0;
						while ($row = mysqli_fetch_array($result))
						{
							$i++;
					?>
							<tr>
								<td style="text-align: center"><?PHP echo $i; ?></td>
								<td><?PHP echo $row['tensp']; ?></td>
								<td><?PHP echo number_format($row['GiaThangCuoc'], 0, '', '.') . "đ" ?></td>
								<td><?PHP echo $row['LuotDat']; ?></td>
								<td><?PHP echo $row['NguoiThamGia']; ?></td>
							</tr>
					<?PHP
						}
					?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>