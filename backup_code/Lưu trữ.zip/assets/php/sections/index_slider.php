<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
       <div class="slider" style="">
        <div class="main-slider-wrapper">
          <button class="slider-control prev" onclick="changeSlide(-1)">&#10094;</button>
          <button class="slider-control next" onclick="changeSlide(1)">&#10095;</button>

          <div class="slides-container">
            <?php
              $query = "SELECT * FROM slider ORDER BY MaSL";
              $result_images = mysqli_query($kn -> con, $query);

              while ($row = mysqli_fetch_array($result_images)) {
            ?>
               
                <div class="slide fade" style="display: block;">
                  <img src="assets/imgs/slider/<?PHP echo $row['hinhanh'] ?>" alt="Slider">
                </div>
                
            <?PHP
              }
            ?>
          </div>

          <div class="dot-container">
            <span class="dot active" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
            <span class="dot" onclick="currentSlide(4)"></span>
            <span class="dot" onclick="currentSlide(5)"></span>
          </div>
        </div>
      </div>
     <script type="text/javascript" src="assets/js/slider.js"></script>
</body>
</html>