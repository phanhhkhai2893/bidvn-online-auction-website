<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
  <form id="" method="post" action="" class="search" style="">
     <i class="fa fa-search" aria-hidden="true"></i>
    <input name="key" type="text" placeholder="Tìm sản phẩm...">
    <div id="suggestion-box" class="dropdown-content"></div>
    <input name="tk" type="submit" value="Tìm kiếm">
  </form>
	
<?PHP
	if (isset($_POST['tk']))
	{
		$keyword = $_POST['key'];
		header('Location: sanpham_searched.php?keyword=' . $keyword);
	}
?>
</body>
</html>