<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<div id="gioithieu" class="info">
        <div class="about-container">
            <div class="content-box">
                <h2 class="main-title">BIDVN - Trang Web Đấu Giá Của Người Việt</h2>
                <h4 class="">Nền tảng đấu giá thế hệ mới, nơi bạn làm chủ mức giá!</h4>
                <div class="collapsible-content">
                    <p>BIDVN tự hào là nền tảng đấu giá trực tuyến đột phá, được thiết kế để mang đến trải nghiệm mua sắm thông minh, tiết kiệm và đầy kịch tính cho người tiêu dùng Việt Nam. Chúng tôi không chỉ là một trang web đấu giá, mà còn là cánh cửa giúp bạn sở hữu các sản phẩm chất lượng với mức giá không tưởng.</p>

                    <p class="secondary-info">Tại BIDVN, chúng tôi hiểu rằng thời gian là tiền bạc. Mọi quy trình đấu giá đều được tối ưu hóa để diễn ra nhanh chóng và minh bạch:

    <br>&#8226;&nbsp;Quy trình đơn giản: Chỉ với vài cú nhấp chuột, bạn đã có thể tham gia đấu giá các sản phẩm từ điện tử, thời trang, đồ gia dụng cho đến các vật phẩm sưu tầm giá trị.

    <br>&#8226;&nbsp;Tiết kiệm tiền tối đa: Cơ chế đấu giá ngược, đấu giá thầu kín, hoặc đấu giá truyền thống của chúng tôi luôn tạo cơ hội để người dùng có thể mua hàng với giá thấp hơn rất nhiều so với thị trường. Tiết kiệm tiền chưa bao giờ dễ dàng và hấp dẫn đến thế!</p>

                    <p class="tertiary-info">Chúng tôi biến việc mua sắm thành một trò chơi đầy cảm xúc. BIDVN mang lại sự hấp dẫn thông qua:

    <br>&#8226;&nbsp;Cảm giác chiến thắng: Sự hồi hộp trong từng giây cuối cùng của phiên đấu, và niềm vui vỡ òa khi trở thành người thắng cuộc.

    <br>&#8226;&nbsp;Đa dạng sản phẩm: Bộ sưu tập sản phẩm được cập nhật liên tục, đảm bảo bạn luôn tìm thấy những món hàng độc đáo và có giá trị mà bạn đang tìm kiếm.

    <br>&#8226;&nbsp;Minh bạch tuyệt đối: Mọi giao dịch, lịch sử đấu giá, và thông tin sản phẩm đều được công khai, đảm bảo môi trường đấu giá công bằng cho tất cả mọi người.</p>
                </div>

                <button class="expand-button">Mở rộng</button>
            </div>
        </div>
      </div>
</body>
</html>