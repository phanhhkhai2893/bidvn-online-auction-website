<html>
<body>
   <?PHP
    if (isset($_GET['masp']))
    {
      $masp = mysqli_real_escape_string($kn->con, $_GET['masp']);

      $query = "SELECT *, san_pham.mota as m, nguoi_dung.diachi as d FROM (san_pham INNER JOIN danh_muc ON san_pham.MaDM = danh_muc.MaDM) INNER JOIN nguoi_dung ON san_pham.MaND = nguoi_dung.MaND WHERE MaSP = '$masp'";
      $result = mysqli_query($kn -> con, $query)
        or die("Lỗi DTB");
      $row = mysqli_fetch_array($result);
  ?>
    <div class="detail-container">
        <header class="page-header">
        <div class="product-header">
              <h3 href="#" class="header-link active"><?PHP echo $row['tendm'] . " > " . $row['tensp']; ?></h3>
            </div>
        </header>

        <div class="detail-main-content">
            <div class="detail-gallery">
                <div class="main-image">
<!--
                    <img src="assets/imgs/product/DSHA001/iPhone 15 Pro Max 256GB 1.jpg" alt="iPhone 13 Pro Max Vàng">
                    <div class="image-menu"><i class="fas fa-ellipsis-v"></i></div>
                    <div class="image-nav left"><i class="fas fa-chevron-left"></i></div>
                    <div class="image-nav right"><i class="fas fa-chevron-right"></i></div>
-->
               
            <?PHP
                $madsha = $row['MaDSHA'];
                $query = "SELECT * FROM danh_sach_hinh_anh WHERE MaDSHA = '$madsha'";
                $result = mysqli_query($kn -> con, $query)
                  or die("Lỗi DTB");
                $mainimg = mysqli_fetch_array($result);
            ?>
                  <img src="assets/imgs/product/<?PHP echo $madsha; ?>/<?PHP echo $mainimg['hinhanh']; ?>" alt="<?PHP echo $mainimg['hinhanh']; ?>">
                </div>
                <div class="thumbnail-bar">
            <?PHP
                mysqli_data_seek($result, 0);
                while ($row1 = mysqli_fetch_array($result))
                {
            ?>
                    <img class="thumbnail" src="assets/imgs/product/<?PHP echo $madsha; ?>/<?PHP echo $row1['hinhanh']; ?>" alt="<?PHP echo $row1['hinhanh']; ?>">
            <?PHP
                }
            ?>
                </div>
            </div>

            <div class="detail-details-area">
                
                <div class="detail-header-info">
                    <h1><?PHP echo $row['tensp']; ?></h1>
                    <div class="price-section">
                        <span class="old-price">Giá khởi điểm: <?PHP echo number_format($row['gia_khoidiem'], 0, '', '.') . "đ"; ?></span>
                    </div>
                    <div class="price-section">
                        <span class="price">Giá hiện tại: <?PHP echo number_format($row['gia_hientai'], 0, '', '.') . "đ"; ?></span>
                    </div>
                    <p class="donation-info">
                        <i class="fa fa-user" aria-hidden="true"></i> <?PHP echo $row['hoten']; ?>
                    </p>

                    <p class="donation-info">
                        <i class="fa fa-map-marker" aria-hidden="true"></i> <?PHP echo $row['diachi']; ?>
                    </p>
                    <p class="update-info">Ngày đăng <?PHP echo $row['thoigian_batdau']; ?></p>
                </div>
				
				<div class="countdown-container">
					<h3>Thời Gian Còn Lại:</h3>
					<div id="auction-countdown" class="countdown-timer">
						<span class="countdown-block">
							<span id="days" class="number">00</span>
							<span class="label">Ngày</span>
						</span>
						<span class="separator">:</span>
						<span class="countdown-block">
							<span id="hours" class="number">00</span>
							<span class="label">Giờ</span>
						</span>
						<span class="separator">:</span>
						<span class="countdown-block">
							<span id="minutes" class="number">00</span>
							<span class="label">Phút</span>
						</span>
						<span class="separator">:</span>
						<span class="countdown-block">
							<span id="seconds" class="number">00</span>
							<span class="label">Giây</span>
						</span>
					</div>
					<div id="countdown-message" class="countdown-message"></div>
				</div>

				<form class="contact-section" action="" method="post">
					<div class="phone-number">Bước Giá: <?PHP echo $row['buocgia']; ?></div>
					<input class="chat-button" name="tragia" type="submit" value="Trả giá">
				</form>
              <div class="detail-content-wrapper">
                    <div class="detail-tabs">
                        <div class="tab-item active">Mô tả chi tiết</div>
                    </div>

                    <div class="detail-description-section">
                       <p><?PHP echo $row['m']; ?></p>
                        <p>SĐT liên hệ: <?PHP echo $row['sdt']; ?></p>
                    </div>
                </div>
              </div> 
            </div> 
          </div>
          
      <?PHP
        }
	
		if (isset($_POST['tragia']))
		{
			$ghgia = $row['gia_hientai'];
			$ghmand = $_SESSION['mand'];
			$ghmasp = $row['MaSP'];
			if (isset($_SESSION['mand']) && (isset($_SESSION['role']) && $_SESSION['role'] == "Người mua"))
			{
				$query = "
					INSERT INTO `gio_hang` (
						`soluong`,
						`thanhtien`,
						`MaND`,
						`MaSP`
					) VALUES (
						1,
						$ghgia,
						'$ghmand',
						'$ghmasp'
					)
				";
				$result = mysqli_query($kn->con, $query)
					or die("Lỗi DTB: " . mysqli_error($kn->con));

				if ($result) {
					echo "<meta http-equiv='refresh' content='0; url=sanpham_detail.php?masp=$ghmasp' />";
				} else {
					echo "Lỗi chèn dữ liệu: " . mysqli_error($kn->con);
				}
			}
		}
      ?>
</body>
</html>
