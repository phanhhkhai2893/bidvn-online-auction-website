<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
      <div id="sanpham" class="product">
        <div class="product-header">
          <h3 class="header-link active">Sản phẩm đang được đấu giá</h3>
        </div>

        <div class="product-list-container">
          <div class="product-grid">
            <?PHP
              $query = "SELECT * FROM (san_pham INNER JOIN nguoi_dung ON san_pham.MaND = nguoi_dung.MaND) INNER JOIN danh_sach_hinh_anh ON san_pham.MaDSHA = danh_sach_hinh_anh.MaDSHA GROUP BY san_pham.MaSP";
              $result = mysqli_query($kn -> con, $query)
                or die("Lỗi DTB");
              while ($row = mysqli_fetch_array($result))
              {
                $ma = $row['MaSP'];
				  
			  	$check_query = "SELECT COUNT(*) AS count_in_cart FROM gio_hang WHERE MaSP = '$ma'";

				// CẢNH BÁO: Đây là SQL Injection-Prone. Cần dùng Prepared Statements nếu code thật.

				$check_result = mysqli_query($kn->con, $check_query);

				if (!$check_result) {
					// Xử lý lỗi nếu truy vấn kiểm tra thất bại
					die("Lỗi kiểm tra giỏ hàng: " . mysqli_error($kn->con));
				}
				  
				$check_row = mysqli_fetch_assoc($check_result);
				$is_in_cart = ($check_row['count_in_cart'] > 0);

				mysqli_free_result($check_result); // Giải phóng bộ nhớ của kết quả kiểm tra

				// 2. Chỉ hiển thị thẻ <a> nếu sản phẩm CHƯA có trong giỏ hàng
				if (!$is_in_cart) {
            ?>
                <a href="sanpham_detail.php?masp=<?PHP echo $row['MaSP']; ?>" class="product-item">
                  <img class="image-placeholder" src="assets/imgs/product/<?PHP echo $row['MaDSHA']; ?>/<?PHP echo $row['hinhanh']; ?>" alt="" />
                  
                  <div class="product-info">
                      <h3 class="product-name"><?PHP echo $row['tensp']; ?></h3>
                      <p class="product-des"><?PHP if (strlen($row['mota']) > 25) echo substr($row['mota'], 0, 25) . "..."; else echo $row['mota']; ?></p>
                      <p class="product-price"><?PHP echo number_format($row['gia_hientai'], 0, '', '.') . "đ"; ?></p>
                      <div class="product-footer">
                          <span class="location">
                              <span class="material-icons"><i class="fa fa-user" aria-hidden="true"></i></span>&nbsp; <?PHP echo $row['hoten'] ?>
                          </span>
                      </div>
                  </div>
                </a>
            <?PHP
				}
              }
            ?>
          </div>
        </div>
      </div>
</body>
</html>