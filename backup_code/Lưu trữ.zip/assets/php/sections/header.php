<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<header class="header">
<!--    <div class="container">-->
      <div class="header-content">
        <div class="logo">
            <a href="index.php">
              
            </a>
        </div>

        <nav class="main-nav">
            <a href="#" class="nav-item active">Đấu Giá</a>
            <a href="#danhmuc" class="nav-item">Danh Mục</a>
            <a href="#sanpham" class="nav-item">Sản Phẩm</a>
            <a href="#gioithieu" class="nav-item">Giới Thiệu</a>
            <a href="#lienhe" class="nav-item">Liên Hệ</a>
        </nav>
		  
		  <?php
		  	if (isset($_SESSION['tennd']))
			{
				if (isset($_SESSION['role']) && $_SESSION['role'] == "Admin")
				{
			?>
					<form action="" method="post">
						<input name="toAdminSite" type="submit" class="action-btn logged-in-btn" value="Quản trị viên" />
					</form>
					<div class="user-dropdown-area">
						<div class="user-profile">
							<i class="fa fa-user-circle" aria-hidden="true"></i>
							<span class="user-btn"><?php echo htmlspecialchars($_SESSION['tennd']); ?></span>
							<div class="dropdown-arrow">
								<i class="fas fa-chevron-down"></i>
							</div>
						</div>

						<div id="dropdown-menu" class="dropdown-content">
							<a href="#">Quản trị viên</a>
							<a href="#">Thông tin cá nhân</a>
							<a href="#">Đổi mật khẩu</a>
							<form action="" method="post">
								<input name="dangxuat" type="submit" value="Đăng xuất" />
							</form>
						</div>
					</div>
		  
		  <?php
				}
				else if (isset($_SESSION['role']) && $_SESSION['role'] == "Người bán")
				{
			?>

				 <div class="icon-group ">
					<a class="icon-button">
						<i class="fa fa-bell" aria-hidden="true"></i>
					</a>
				  </div>
				<button class="action-btn logged-in-btn">Quản lý tin</button>

				<button class="action-btn logged-in-btn post-btn">Đăng tin</button>

				<div class="user-dropdown-area">
					<div class="user-profile">
						<i class="fa fa-user-circle" aria-hidden="true"></i>
						<span class="user-btn"><?php echo htmlspecialchars($_SESSION['tennd']); ?></span>
						<div class="dropdown-arrow">
							<i class="fas fa-chevron-down"></i>
						</div>
					</div>

					<div id="dropdown-menu" class="dropdown-content">
						<a href="#">Quản lý tin đăng</a>
						<a href="#">Thông tin cá nhân</a>
						<a href="#">Đổi mật khẩu</a>
						<form action="" method="post">
							<input name="dangxuat" type="submit" value="Đăng xuất" />
						</form>
					</div>
				</div>
			<?php
				}
				else if (isset($_SESSION['role']) && $_SESSION['role'] == "Người mua")
				{
			?>
		  

				 <div class="icon-group ">
					<a class="icon-button">
						<i class="fa fa-heart" aria-hidden="true"></i>
					</a>
					<a class="icon-button">
						<i class="fa fa-bell" aria-hidden="true"></i>
					</a>
					<a href="giohang.php" class="icon-button">
						<i class="fa fa-shopping-cart" aria-hidden="true"></i>
					</a>
				  </div>
				<button class="action-btn logged-in-btn">Danh sách đấu giá</button>

				<div class="user-dropdown-area">
					<div class="user-profile">
						<i class="fa fa-user-circle" aria-hidden="true"></i>
						<span class="user-btn"><?php echo htmlspecialchars($_SESSION['tennd']); ?></span>
						<div class="dropdown-arrow">
							<i class="fas fa-chevron-down"></i>
						</div>
					</div>

					<div id="dropdown-menu" class="dropdown-content">
						<a href="#">Sản phẩm yêu thích</a>
						<a href="#">Thông tin cá nhân</a>
						<a href="#">Đổi mật khẩu</a>
						<form action="" method="post">
							<input name="dangxuat" type="submit" value="Đăng xuất" />
						</form>
					</div>
				</div>
			<?php
				}
		  	}
			else
			{
			?>
			  <a id="register-btn" class="signup-button">
				  Đăng ký
			  </a>

			  <button id="login-btn" class="login-button">
				  Đăng nhập
			  </button>
			<?php
			}
		  	if (isset($_POST['signout']))
			{
				header('Location: index.php');
			}
			?>
        </div>
<!--    </div>-->
  </header>
	
<?PHP
	if (isset($_POST['toAdminSite']))
	{
		header('Location: admin_index.php?hoten=' . $hoten);
	}
	if (isset($_POST['dangxuat']))
	{
		$_SESSION = array();

		if (ini_get("session.use_cookies")) {
			$params = session_get_cookie_params();
			setcookie(session_name(), '', time() - 42000,
			$params["path"], $params["domain"],
			$params["secure"], $params["httponly"]
			);
		}

		session_destroy();
		echo "<meta http-equiv='refresh' content='0; url=index.php' />";
	}
?>
</body>
</html>