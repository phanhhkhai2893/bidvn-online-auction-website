
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<div id="danhmuc" class="category-container">
	<div class="category-grid">
	  <?PHP
		$query = "SELECT * FROM danh_muc";
		$result = mysqli_query($kn -> con, $query)
		  or die("Lỗi DTB");
		while ($row = mysqli_fetch_array($result))
		{
		  $ma = $row['MaDM'];
	  ?>
		  <a href="sanpham_danhmuc.php?madm=<?PHP echo $ma; ?>" class="category-item">
			  <img class="icon-placeholder" src="assets/imgs/category/<?PHP echo $row['MaDM']; ?>.jpg" alt="<?PHP echo $row['tendm']; ?>" />
			  <p class="category-name">
				<?PHP 
				  echo $row['tendm'];
				?>
			  </p>
		  </a>
	  <?PHP
		}
	  ?>
	</div>
  </div>
</body>
</html>