-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th10 05, 2025 lúc 11:45 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `BIDVN_DTB`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_hoa_don`
--

CREATE TABLE `chi_tiet_hoa_don` (
  `soluong` int(11) NOT NULL,
  `thanhtien` float NOT NULL,
  `SoHD` varchar(10) NOT NULL,
  `MaSP` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_hoa_don`
--

INSERT INTO `chi_tiet_hoa_don` (`soluong`, `thanhtien`, `SoHD`, `MaSP`) VALUES
(1, 28500000, 'HD1', 'SP1'),
(1, 32000000, 'HD2', 'SP2'),
(1, 550000000, 'HD3', 'SP3'),
(1, 21000000, 'HD4', 'SP4'),
(1, 24000000, 'HD5', 'SP5'),
(1, 25000000, 'HD6', 'SP6'),
(1, 3200000, 'HD7', 'SP7'),
(1, 52000000, 'HD8', 'SP8'),
(1, 21000000, 'HD9', 'SP9'),
(1, 6200000, 'HD10', 'SP10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_muc`
--

CREATE TABLE `danh_muc` (
  `MaDM` varchar(10) NOT NULL,
  `tendm` varchar(30) NOT NULL,
  `mota` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_muc`
--

INSERT INTO `danh_muc` (`MaDM`, `tendm`, `mota`) VALUES
('DM1', 'Điện thoại', 'Các loại điện thoại thông minh'),
('DM11', 'Khác', 'Danh mục sản phẩm khác'),
('DM2', 'Máy tính', 'Laptop và máy tính để bàn'),
('DM3', 'Đồng hồ', 'Đồng hồ đeo tay và đồng hồ treo tường'),
('DM4', 'Máy ảnh', 'Máy ảnh và thiết bị nhiếp ảnh'),
('DM5', 'Điện tử', 'Thiết bị điện tử gia dụng'),
('DM6', 'Xe cộ', 'Xe máy, xe đạp, phụ tùng'),
('DM7', 'Thời trang', 'Quần áo, giày dép, phụ kiện'),
('DM8', 'Đồ cổ', 'Đồ sưu tầm, đồ cổ quý hiếm'),
('DM9', 'Nghệ thuật', 'Tranh ảnh, tác phẩm nghệ thuật');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_muc_con`
--

CREATE TABLE `danh_muc_con` (
  `MaDMCon` varchar(10) NOT NULL,
  `tendm` varchar(30) NOT NULL,
  `mota` varchar(50) NOT NULL,
  `hinhanh` varchar(30) NOT NULL,
  `MaDM` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_muc_con`
--

INSERT INTO `danh_muc_con` (`MaDMCon`, `tendm`, `mota`, `hinhanh`, `MaDM`) VALUES
('DMC1', 'Apple', 'Hãng điện thoại Apple của Mỹ', 'brand_apple.png', 'DM1'),
('DMC10', 'OnePlus', 'Hãng điện thoại OnePlus của Trung Quốc', 'brand_oneplus.png', 'DM1'),
('DMC11', 'Dell', 'Hãng Laptop Dell', 'brand_dell.png', 'DM2'),
('DMC12', 'HP', 'Hãng Laptop HP', 'brand_hp.png', 'DM2'),
('DMC13', 'Asus', 'Hãng Laptop Asus', 'brand_asus.png', 'DM2'),
('DMC14', 'Apple', 'Hãng Laptop Apple', 'brand_apple.png', 'DM2'),
('DMC15', 'Lenovo', 'Hãng Laptop Lenovo', 'brand_lenovo.png', 'DM2'),
('DMC16', 'Acer', 'Hãng Laptop Acer', 'brand_acer.png', 'DM2'),
('DMC17', 'MSI', 'Hãng Laptop MSI', 'brand_msi.png', 'DM2'),
('DMC18', 'Microsoft', 'Hãng Laptop Microsoft', 'brand_microsoft.png', 'DM2'),
('DMC19', 'LG', 'Hãng Laptop LG', 'brand_lg.png', 'DM2'),
('DMC2', 'Samsung', 'Hãng điện thoại Samsung của Hàn Quốc', 'brand_samsung.png', 'DM1'),
('DMC20', 'Gigabyte', 'Hãng Laptop Gigabyte', 'brand_gigabyte.png', 'DM2'),
('DMC21', 'Rolex', 'Hãng Đồng hồ xa xỉ Thụy Sĩ', 'brand_rolex.png', 'DM3'),
('DMC22', 'Patek Philippe', 'Hãng Đồng hồ siêu xa xỉ Thụy Sĩ', 'brand_patek_philippe.png', 'DM3'),
('DMC23', 'Omega', 'Hãng Đồng hồ Thụy Sĩ nổi tiếng với dòng Speedmaste', 'brand_omega.png', 'DM3'),
('DMC24', 'Audemars Piguet', 'Hãng Đồng hồ Thụy Sĩ, nổi tiếng Royal Oak', 'brand_audemars_piguet.png', 'DM3'),
('DMC25', 'Cartier', 'Hãng Đồng hồ và trang sức cao cấp Pháp/Thụy Sĩ', 'brand_cartier.png', 'DM3'),
('DMC26', 'Longines', 'Hãng Đồng hồ Thụy Sĩ, tập trung vào sự thanh lịch', 'brand_longines.png', 'DM3'),
('DMC27', 'TAG Heuer', 'Hãng Đồng hồ Thụy Sĩ, gắn liền với đua xe thể thao', 'brand_tag_heuer.png', 'DM3'),
('DMC28', 'Tissot', 'Hãng Đồng hồ Thụy Sĩ, phổ biến, chất lượng tốt', 'brand_tissot.png', 'DM3'),
('DMC29', 'Seiko', 'Hãng Đồng hồ Nhật Bản, công nghệ tiên tiến', 'brand_seiko.png', 'DM3'),
('DMC3', 'Oppo', 'Hãng điện thoại Oppo của Trung Quốc', 'brand_oppo.png', 'DM1'),
('DMC30', 'Citizen', 'Hãng Đồng hồ Nhật Bản, nổi tiếng công nghệ Eco-Dri', 'brand_citizen.png', 'DM3'),
('DMC31', 'Canon', 'Hãng Máy ảnh DSLR và Mirrorless hàng đầu Nhật Bản', 'brand_canon.png', 'DM4'),
('DMC32', 'Nikon', 'Hãng Máy ảnh Nhật Bản, nổi tiếng chất lượng quang ', 'brand_nikon.png', 'DM4'),
('DMC33', 'Sony', 'Hãng Máy ảnh Mirrorless full-frame, công nghệ AF v', 'brand_sony.png', 'DM4'),
('DMC34', 'Fujifilm', 'Hãng Máy ảnh Mirrorless, thiết kế cổ điển, màu sắc', 'brand_fujifilm.png', 'DM4'),
('DMC35', 'Panasonic', 'Hãng Máy ảnh Hybrid, mạnh về video (dòng Lumix)', 'brand_panasonic.png', 'DM4'),
('DMC36', 'Olympus', 'Hãng Máy ảnh Micro Four Thirds nhỏ gọn, chống rung', 'brand_olympus.png', 'DM4'),
('DMC37', 'Leica', 'Hãng Máy ảnh cao cấp Đức, ống kính huyền thoại', 'brand_leica.png', 'DM4'),
('DMC38', 'Hasselblad', 'Hãng Máy ảnh định dạng trung bình Thụy Điển', 'brand_hasselblad.png', 'DM4'),
('DMC39', 'GoPro', 'Hãng Máy ảnh hành động (Action Camera) của Mỹ', 'brand_gopro.png', 'DM4'),
('DMC4', 'Xiaomi', 'Hãng điện thoại Xiaomi của Trung Quốc', 'brand_xiaomi.png', 'DM1'),
('DMC40', 'Ricoh/Pentax', 'Hãng Máy ảnh Nhật Bản (Compact cao cấp và DSLR siê', 'brand_ricoh_pentax.png', 'DM4'),
('DMC41', 'Samsung', 'Hãng Điện tử gia dụng lớn nhất Hàn Quốc, công nghệ', 'brand_samsung.png', 'DM5'),
('DMC42', 'LG', 'Hãng Điện tử gia dụng Hàn Quốc, nổi tiếng công ngh', 'brand_lg.png', 'DM5'),
('DMC43', 'Panasonic', 'Hãng Điện tử gia dụng Nhật Bản, bền bỉ, tiết kiệm ', 'brand_panasonic.png', 'DM5'),
('DMC44', 'Hitachi', 'Hãng Điện tử gia dụng Nhật Bản, mạnh về Tủ lạnh ca', 'brand_hitachi.png', 'DM5'),
('DMC45', 'Electrolux', 'Hãng Điện tử gia dụng Thụy Điển, nổi tiếng Máy giặ', 'brand_electrolux.png', 'DM5'),
('DMC46', 'Toshiba', 'Hãng Điện tử gia dụng Nhật Bản, sản phẩm bền, dễ s', 'brand_toshiba.png', 'DM5'),
('DMC47', 'Bosch', 'Hãng Điện tử gia dụng cao cấp Đức, chất lượng chuẩ', 'brand_bosch.png', 'DM5'),
('DMC48', 'Sharp', 'Hãng Điện tử gia dụng Nhật Bản, công nghệ Plasmacl', 'brand_sharp.png', 'DM5'),
('DMC49', 'Aqua', 'Hãng Điện tử gia dụng (Tủ lạnh, Máy giặt) phân khú', 'brand_aqua.png', 'DM5'),
('DMC5', 'Nokia', 'Hãng điện thoại Nokia của Phần Lan', 'brand_nokia.png', 'DM1'),
('DMC50', 'Midea', 'Hãng Điện tử gia dụng Trung Quốc, đa dạng sản phẩm', 'brand_midea.png', 'DM5'),
('DMC6', 'Realme', 'Hãng điện thoại Realme của Trung Quốc', 'brand_realme.png', 'DM1'),
('DMC61', 'Honda', 'Hãng Xe Nhật Bản, dẫn đầu cả Ô tô và Xe máy phổ th', 'brand_honda.png', 'DM6'),
('DMC62', 'Toyota', 'Hãng Ô tô lớn nhất thế giới, nổi tiếng bền bỉ, Hyb', 'brand_toyota.png', 'DM6'),
('DMC63', 'Yamaha', 'Hãng Xe máy Nhật Bản, nổi tiếng Xe thể thao và Xe ', 'brand_yamaha.png', 'DM6'),
('DMC64', 'Suzuki', 'Hãng Xe Nhật Bản, sản xuất cả Ô tô nhỏ gọn và Xe m', 'brand_suzuki.png', 'DM6'),
('DMC65', 'Kawasaki', 'Hãng Xe máy Nhật Bản, chuyên về phân khối lớn và x', 'brand_kawasaki.png', 'DM6'),
('DMC66', 'Mercedes-Benz', 'Hãng Ô tô sang trọng Đức, biểu tượng của đẳng cấp', 'brand_mercedes_benz.png', 'DM6'),
('DMC67', 'BMW', 'Hãng Xe Đức, mạnh về Ô tô thể thao và Xe máy cao c', 'brand_bmw.png', 'DM6'),
('DMC68', 'Ford', 'Hãng Ô tô Mỹ, nổi tiếng với xe bán tải, SUV và xe ', 'brand_ford.png', 'DM6'),
('DMC69', 'Vespa/Piaggio', 'Hãng Xe máy Ý, nổi tiếng với thiết kế cổ điển và s', 'brand_vespa_piaggio.png', 'DM6'),
('DMC7', 'Vivo', 'Hãng điện thoại Vivo của Trung Quốc', 'brand_vivo.png', 'DM1'),
('DMC70', 'VinFast', 'Hãng Xe Việt Nam, sản xuất cả Ô tô và Xe máy điện', 'brand_vinfast.png', 'DM6'),
('DMC71', 'Khác', '', '', 'DM11'),
('DMC8', 'Huawei', 'Hãng điện thoại Huawei của Trung Quốc', 'brand_huawei.png', 'DM1'),
('DMC9', 'Sony', 'Hãng điện thoại Sony của Nhật Bản', 'brand_sony.png', 'DM1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_sach_hinh_anh`
--

CREATE TABLE `danh_sach_hinh_anh` (
  `MaDSHA` varchar(10) NOT NULL,
  `hinhanh` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_sach_hinh_anh`
--

INSERT INTO `danh_sach_hinh_anh` (`MaDSHA`, `hinhanh`) VALUES
('DSHA11', 'Canon EOS R5 1.jpg'),
('DSHA11', 'Canon EOS R5 2.jpg'),
('DSHA11', 'Canon EOS R5 3.jpg'),
('DSHA11', 'Canon EOS R5 4.jpg'),
('DSHA11', 'Canon EOS R5 5.jpg'),
('DSHA11', 'Canon EOS R5 6.jpg'),
('DSHA11', 'Canon EOS R5 7.jpg'),
('DSHA12', 'Fujifilm X-T5 1.jpg'),
('DSHA12', 'Fujifilm X-T5 2.jpg'),
('DSHA12', 'Fujifilm X-T5 3.jpg'),
('DSHA12', 'Fujifilm X-T5 4.jpg'),
('DSHA12', 'Fujifilm X-T5 5.jpg'),
('DSHA12', 'Fujifilm X-T5 6.jpg'),
('DSHA13', 'Bộ ấm chén cổ Bát Tràng 1.jpg'),
('DSHA14', 'Tranh sơn dầu phong cảnh 1.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 1.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 2.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 3.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 4.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 5.jpg'),
('DSHA15', 'Đồng hồ cổ treo tường 6.jpg'),
('DSHA2', 'Samsung Galaxy S24 Ultra 1.jpg'),
('DSHA2', 'Samsung Galaxy S24 Ultra 2.jpg'),
('DSHA2', 'Samsung Galaxy S24 Ultra 3.jpg'),
('DSHA2', 'Samsung Galaxy S24 Ultra 4.jpg'),
('DSHA2', 'Samsung Galaxy S24 Ultra 5.jpg'),
('DSHA3', 'Xiaomi 14 Pro 1.jpg'),
('DSHA3', 'Xiaomi 14 Pro 2.jpg'),
('DSHA3', 'Xiaomi 14 Pro 3.jpg'),
('DSHA3', 'Xiaomi 14 Pro 4.jpg'),
('DSHA3', 'Xiaomi 14 Pro 5.jpg'),
('DSHA4', 'MacBook Air M3 2024 1.jpg'),
('DSHA4', 'MacBook Air M3 2024 2.jpg'),
('DSHA4', 'MacBook Air M3 2024 3.jpg'),
('DSHA4', 'MacBook Air M3 2024 4.jpg'),
('DSHA4', 'MacBook Air M3 2024 5.jpg'),
('DSHA5', 'Dell XPS 13 Plus 1.jpg'),
('DSHA5', 'Dell XPS 13 Plus 2.jpg'),
('DSHA5', 'Dell XPS 13 Plus 3.jpg'),
('DSHA5', 'Dell XPS 13 Plus 4.jpg'),
('DSHA5', 'Dell XPS 13 Plus 5.jpg'),
('DSHA5', 'Dell XPS 13 Plus 6.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 1.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 2.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 3.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 4.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 5.jpg'),
('DSHA6', 'ASUS ROG Zephyrus G14 6.jpg'),
('DSHA7', 'Rolex Submariner Date 1.jpg'),
('DSHA7', 'Rolex Submariner Date 2.jpg'),
('DSHA7', 'Rolex Submariner Date 3.jpg'),
('DSHA7', 'Rolex Submariner Date 4.jpg'),
('DSHA7', 'Rolex Submariner Date 5.jpg'),
('DSHA8', 'Omega Seamaster 300M 1.jpg'),
('DSHA8', 'Omega Seamaster 300M 2.jpg'),
('DSHA8', 'Omega Seamaster 300M 3.jpg'),
('DSHA8', 'Omega Seamaster 300M 4.jpg'),
('DSHA8', 'Omega Seamaster 300M 5.jpg'),
('DSHA9', 'Casio G-Shock MR-G 1.jpg'),
('DSHA9', 'Casio G-Shock MR-G 2.jpg'),
('DSHA9', 'Casio G-Shock MR-G 3.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_sach_yeu_thich`
--

CREATE TABLE `danh_sach_yeu_thich` (
  `MaDS` varchar(10) NOT NULL,
  `ngaythem` datetime NOT NULL,
  `MaND` varchar(10) NOT NULL,
  `MaSP` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_sach_yeu_thich`
--

INSERT INTO `danh_sach_yeu_thich` (`MaDS`, `ngaythem`, `MaND`, `MaSP`) VALUES
('DS1', '2024-03-02 09:00:00', 'ND3', 'SP1'),
('DS10', '2024-03-06 14:50:00', 'ND3', 'SP7'),
('DS11', '2024-03-07 08:40:00', 'ND5', 'SP11'),
('DS12', '2024-03-07 17:30:00', 'ND7', 'SP12'),
('DS13', '2024-03-08 11:25:00', 'ND9', 'SP13'),
('DS14', '2024-03-08 15:10:00', 'ND3', 'SP14'),
('DS15', '2024-03-09 13:45:00', 'ND5', 'SP15'),
('DS2', '2024-03-02 10:00:00', 'ND3', 'SP3'),
('DS3', '2024-03-03 08:30:00', 'ND5', 'SP2'),
('DS4', '2024-03-03 14:20:00', 'ND5', 'SP4'),
('DS5', '2024-03-04 11:00:00', 'ND3', 'SP5'),
('DS6', '2024-03-04 15:45:00', 'ND7', 'SP6'),
('DS7', '2024-03-05 09:30:00', 'ND7', 'SP8'),
('DS8', '2024-03-05 16:20:00', 'ND9', 'SP9'),
('DS9', '2024-03-06 10:15:00', 'ND9', 'SP10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gio_hang`
--

CREATE TABLE `gio_hang` (
  `soluong` int(11) NOT NULL,
  `thanhtien` float NOT NULL,
  `MaND` varchar(10) NOT NULL,
  `MaSP` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don`
--

CREATE TABLE `hoa_don` (
  `SoHD` varchar(10) NOT NULL,
  `noidung` varchar(50) NOT NULL,
  `ngaylap` datetime NOT NULL,
  `phuongthuctt` varchar(20) NOT NULL,
  `MaND` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `hoa_don`
--

INSERT INTO `hoa_don` (`SoHD`, `noidung`, `ngaylap`, `phuongthuctt`, `MaND`) VALUES
('HD1', 'Thanh toán cho iPhone 15 Pro Max', '2024-03-11 09:15:00', 'Chuyển khoản', 'ND5'),
('HD10', 'Thanh toán cho AirPods Pro', '2024-03-20 14:50:00', 'Tiền mặt', 'ND5'),
('HD2', 'Thanh toán cho MacBook Air M2', '2024-03-12 10:30:00', 'Thẻ VISA', 'ND3'),
('HD3', 'Thanh toán cho đồng hồ Rolex', '2024-03-13 14:20:00', 'Tiền mặt', 'ND5'),
('HD4', 'Thanh toán cho máy ảnh Sony', '2024-03-14 11:45:00', 'Chuyển khoản', 'ND9'),
('HD5', 'Thanh toán cho Samsung S24', '2024-03-15 16:30:00', 'Thẻ VISA', 'ND7'),
('HD6', 'Thanh toán cho Dell XPS 13', '2024-03-16 08:20:00', 'Chuyển khoản', 'ND5'),
('HD7', 'Thanh toán cho đồng hồ Casio', '2024-03-17 13:15:00', 'Tiền mặt', 'ND9'),
('HD8', 'Thanh toán cho Canon R5', '2024-03-18 15:40:00', 'Thẻ VISA', 'ND3'),
('HD9', 'Thanh toán cho iPad Pro', '2024-03-19 10:25:00', 'Chuyển khoản', 'ND7');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lich_su_dau_gia`
--

CREATE TABLE `lich_su_dau_gia` (
  `MaLS` varchar(10) NOT NULL,
  `gia_hientai` float NOT NULL,
  `thoigian_dau` datetime NOT NULL,
  `MaND` varchar(10) NOT NULL,
  `MaSP` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `lich_su_dau_gia`
--

INSERT INTO `lich_su_dau_gia` (`MaLS`, `gia_hientai`, `thoigian_dau`, `MaND`, `MaSP`) VALUES
('LS1', 26000000, '2024-03-02 14:30:00', 'ND3', 'SP1'),
('LS10', 24000000, '2024-03-06 16:40:00', 'ND9', 'SP5'),
('LS11', 23000000, '2024-03-06 10:25:00', 'ND3', 'SP6'),
('LS12', 25000000, '2024-03-07 15:35:00', 'ND5', 'SP6'),
('LS13', 2800000, '2024-03-07 08:45:00', 'ND7', 'SP7'),
('LS14', 3200000, '2024-03-08 13:20:00', 'ND9', 'SP7'),
('LS15', 48000000, '2024-03-08 11:10:00', 'ND3', 'SP8'),
('LS16', 52000000, '2024-03-09 17:25:00', 'ND5', 'SP8'),
('LS17', 19500000, '2024-03-09 14:50:00', 'ND7', 'SP9'),
('LS18', 21000000, '2024-03-10 16:15:00', 'ND9', 'SP9'),
('LS19', 5800000, '2024-03-10 12:30:00', 'ND3', 'SP10'),
('LS2', 28500000, '2024-03-03 16:45:00', 'ND5', 'SP1'),
('LS20', 6200000, '2024-03-11 18:40:00', 'ND5', 'SP10'),
('LS3', 29000000, '2024-03-02 15:20:00', 'ND3', 'SP2'),
('LS4', 32000000, '2024-03-03 17:30:00', 'ND5', 'SP2'),
('LS5', 520000000, '2024-03-02 11:15:00', 'ND3', 'SP3'),
('LS6', 550000000, '2024-03-04 10:30:00', 'ND5', 'SP3'),
('LS7', 19000000, '2024-03-04 09:20:00', 'ND7', 'SP4'),
('LS8', 21000000, '2024-03-05 14:15:00', 'ND9', 'SP4'),
('LS9', 23000000, '2024-03-05 11:30:00', 'ND7', 'SP5');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `MaND` varchar(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `hoten` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sdt` varchar(10) NOT NULL,
  `diachi` varchar(100) NOT NULL,
  `avarta` varchar(30) NOT NULL,
  `phanquyen` varchar(10) NOT NULL,
  `ngaydangky` datetime NOT NULL,
  `trangthai` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`MaND`, `username`, `password`, `hoten`, `email`, `sdt`, `diachi`, `avarta`, `phanquyen`, `ngaydangky`, `trangthai`) VALUES
('ND1', 'admin', '123456', 'Phan Hoàng Huy Khải', 'phhkhai2893@gmail.com', '0907636172', 'Phường Mỹ Thới, tỉnh An Giang', '', 'Admin', '2025-11-03 14:03:09', 'Hoạt động'),
('ND10', 'haivan', '123456', 'Văn Thị Hải', 'hai@gmail.com', '0912345687', 'Khánh Hòa', '', 'Người bán', '2024-03-01 00:00:00', 'Hoạt động'),
('ND11', 'quangdo', '123456', 'Đỗ Văn Quang', 'quang@gmail.com', '0912345688', 'Vũng Tàu, TP. Hồ Chí Minh', '', 'Người mua', '2024-03-05 00:00:00', 'Hoạt động'),
('ND12', 'linhnguyen', '123456', 'Nguyễn Thị Linh', 'linh@gmail.com', '0912345681', 'Tri Tôn 2, An Giang', '', 'Người bán', '2024-03-10 00:00:00', 'Hoạt động'),
('ND2', 'thanhngoc', '123456', 'Huỳnh Thị Thanh Ngọc', 'tngoc@gmail.com', '0912345679', 'Quận 3, TP. Hồ Chí Minh', '', 'Người bán', '2024-01-20 00:00:00', 'Hoạt động'),
('ND3', 'tuanle', '123456', 'Lê Anh Tuấn', 'tuan@gmail.com', '0912345680', 'Thanh Xuân, Hà Nội', '', 'Người mua', '2024-01-25 00:00:00', 'Hoạt động'),
('ND4', 'lanpham', '123456', 'Phạm Thị Lan', 'lan@gmail.com', '0912345681', 'Dĩ An, Bình Dương', '', 'Người bán', '2024-02-01 00:00:00', 'Hoạt động'),
('ND5', 'hungvo', '123456', 'Võ Mạnh Hùng', 'hung@gmail.com', '0912345682', 'Đồng Nai', '', 'Người mua', '2024-02-05 00:00:00', 'Hoạt động'),
('ND6', 'minhnguyen', '123456', 'Nguyễn Thị Minh', 'minh@gmail.com', '0912345683', 'Hải Phòng', '', 'Người bán', '2024-02-10 00:00:00', 'Hoạt động'),
('ND7', 'hoangtran', '123456', 'Trần Văn Hoàng', 'hoang@gmail.com', '0912345684', 'Đà Nẵng', '', 'Người mua', '2024-02-15 00:00:00', 'Hoạt động'),
('ND8', 'thuyLe', '123456', 'Lê Thị Thủy', 'thuy@gmail.com', '0912345685', 'Ninh Kiều, Cần Thơ', '', 'Người bán', '2024-02-20 00:00:00', 'Hoạt động'),
('ND9', 'dungpham', '123456', 'Phạm Văn Dũng', 'dung@gmail.com', '0912345686', 'Thừa Thiên Huế', '', 'Người mua', '2024-02-25 00:00:00', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `san_pham`
--

CREATE TABLE `san_pham` (
  `MaSP` varchar(10) NOT NULL,
  `tensp` varchar(30) NOT NULL,
  `mota` varchar(1000) NOT NULL,
  `gia_khoidiem` float NOT NULL,
  `gia_hientai` float NOT NULL,
  `buocgia` float NOT NULL,
  `thoigian_batdau` datetime NOT NULL,
  `thoigian_ketthuc` datetime NOT NULL,
  `trangthai` varchar(15) NOT NULL,
  `MaDSHA` varchar(10) NOT NULL,
  `MaND` varchar(10) NOT NULL,
  `MaDM` varchar(10) NOT NULL,
  `MaDMCon` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `san_pham`
--

INSERT INTO `san_pham` (`MaSP`, `tensp`, `mota`, `gia_khoidiem`, `gia_hientai`, `buocgia`, `thoigian_batdau`, `thoigian_ketthuc`, `trangthai`, `MaDSHA`, `MaND`, `MaDM`, `MaDMCon`) VALUES
('SP1', 'iPhone 15 Pro Max 256GB', 'iPhone 15 Pro Max 256GB màu Titan, mới 100%, full box', 25000000, 28500000, 500000, '2024-03-15 08:00:00', '2024-03-20 20:00:00', 'Đang đấu giá', 'DSHA1', 'ND2', 'DM1', 'DMC1'),
('SP10', 'Sony A7IV Body', 'Sony Alpha A7IV fullframe, shutter 5k, like new', 32000000, 36000000, 800000, '2024-03-17 15:00:00', '2024-03-28 21:00:00', 'Đang đấu giá', 'DSHA10', 'ND8', 'DM4', 'DMC33'),
('SP11', 'Canon EOS R5', 'Canon R5 + 24-105mm F4L, 45MP, 8K video', 45000000, 52000000, 1500000, '2024-03-18 11:00:00', '2024-03-29 16:00:00', 'Đang đấu giá', 'DSHA11', 'ND10', 'DM4', 'DMC31'),
('SP12', 'Fujifilm X-T5', 'Fujifilm X-T5 + 16-80mm, film simulation classic', 28000000, 32000000, 700000, '2024-03-19 14:00:00', '2024-03-30 18:00:00', 'Đang đấu giá', 'DSHA12', 'ND12', 'DM4', 'DMC34'),
('SP13', 'Bộ ấm chén cổ Bát Tràng', 'Bộ ấm chén cổ Bát Tràng thế kỷ 19, men rạn', 15000000, 18500000, 500000, '2024-03-20 09:00:00', '2024-03-31 20:00:00', 'Đang đấu giá', 'DSHA13', 'ND2', 'DM8', ''),
('SP14', 'Tranh sơn dầu phong cảnh', 'Tranh sơn dầu phong cảnh Việt Nam, kích thước 80x120cm', 8000000, 9500000, 200000, '2024-03-21 10:00:00', '2024-04-01 17:00:00', 'Đang đấu giá', 'DSHA14', 'ND4', 'DM9', ''),
('SP15', 'Đồng hồ cổ treo tường', 'Đồng hồ cổ treo tường Pháp, thế kỷ 19, còn hoạt động', 12000000, 14500000, 400000, '2024-03-22 08:00:00', '2024-04-02 19:00:00', 'Đang đấu giá', 'DSHA15', 'ND6', 'DM8', ''),
('SP2', 'Samsung Galaxy S24 Ultra', 'Samsung S24 Ultra 512GB, chip Snapdragon, hàng chính hãng', 22000000, 25500000, 300000, '2024-03-16 09:00:00', '2024-03-21 18:00:00', 'Đang đấu giá', 'DSHA2', 'ND4', 'DM1', ' DMC2'),
('SP3', 'Xiaomi 14 Pro', 'Xiaomi 14 Pro 512GB, camera Leica, flagship 2024', 18000000, 21000000, 400000, '2024-03-14 10:00:00', '2024-03-19 22:00:00', 'Đang đấu giá', 'DSHA3', 'ND6', 'DM1', 'DMC4'),
('SP4', 'MacBook Air M3 2024', 'MacBook Air M3 13 inch, 16GB RAM, 512GB SSD, like new', 28000000, 32000000, 800000, '2024-03-15 14:00:00', '2024-03-22 16:00:00', 'Đang đấu giá', 'DSHA4', 'ND8', 'DM2', 'DMC14'),
('SP5', 'Dell XPS 13 Plus', 'Dell XPS 13 Plus OLED, i7, 16GB, 1TB SSD, bảo hành 2 năm', 22000000, 26000000, 600000, '2024-03-16 11:00:00', '2024-03-23 15:00:00', 'Đang đấu giá', 'DSHA5', 'ND10', 'DM2', 'DMC11'),
('SP6', 'ASUS ROG Zephyrus G14', 'Laptop gaming ASUS ROG RTX 4060, Ryzen 9, 32GB RAM', 35000000, 39000000, 1000000, '2024-03-17 09:00:00', '2024-03-24 17:00:00', 'Đang đấu giá', 'DSHA6', 'ND12', 'DM2', 'DMC13'),
('SP7', 'Rolex Submariner Date', 'Rolex Submariner 126610LN mới 2023, full papers', 500000000, 550000000, 10000000, '2024-03-14 08:00:00', '2024-03-25 20:00:00', 'Đang đấu giá', 'DSHA7', 'ND2', 'DM3', 'DMC21'),
('SP8', 'Omega Seamaster 300M', 'Omega Seamaster Diver 300M, ceramic bezel, automatic', 120000000, 135000000, 3000000, '2024-03-15 10:00:00', '2024-03-26 18:00:00', 'Đang đấu giá', 'DSHA8', 'ND4', 'DM3', ' DMC23'),
('SP9', 'Casio G-Shock MR-G', 'Casio G-Shock MR-G limited edition, titanium', 25000000, 28000000, 500000, '2024-03-16 13:00:00', '2024-03-27 19:00:00', 'Đang đấu giá', 'DSHA9', 'ND6', 'DM3', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slider`
--

CREATE TABLE `slider` (
  `MaSL` varchar(10) NOT NULL,
  `hinhanh` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `slider`
--

INSERT INTO `slider` (`MaSL`, `hinhanh`) VALUES
('SL1', 'slider 1.jpeg'),
('SL2', 'slider 2.jpeg'),
('SL3', 'slider 3.jpeg'),
('SL4', 'slider 4.jpeg'),
('SL5', 'slider 5.jpeg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thong_bao`
--

CREATE TABLE `thong_bao` (
  `MaTB` varchar(10) NOT NULL,
  `tieude` varchar(30) NOT NULL,
  `noidung` varchar(256) NOT NULL,
  `loaitb` varchar(30) NOT NULL,
  `ngaytb` datetime NOT NULL,
  `MaND` varchar(10) NOT NULL,
  `MaSP` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `thong_bao`
--

INSERT INTO `thong_bao` (`MaTB`, `tieude`, `noidung`, `loaitb`, `ngaytb`, `MaND`, `MaSP`) VALUES
('TB1', 'Đấu giá thành công', 'Bạn đã thắng phiên đấu giá iPhone 15 Pro Max', 'Thắng cuộc', '2024-03-10 20:05:00', 'ND5', 'SP1'),
('TB10', 'Đấu giá sắp kết thúc', 'iPad Pro của bạn sắp kết thúc đấu giá', 'Cảnh báo', '2024-03-18 15:30:00', 'ND6', 'SP9'),
('TB11', 'Có người ra giá', 'Có người vừa ra giá cho AirPods Pro 2 của bạn', 'Cập nhật', '2024-03-11 13:45:00', 'ND8', 'SP10'),
('TB12', 'Đấu giá thành công', 'Bạn đã thắng phiên đấu giá TV Samsung', 'Thắng cuộc', '2024-03-20 18:05:00', 'ND3', 'SP11'),
('TB13', 'Sản phẩm mới được duyệt', 'Bộ ấm chén cổ của bạn đã được duyệt đăng bán', 'Hệ thống', '2024-03-12 08:30:00', 'ND12', 'SP12'),
('TB14', 'Có người bình luận', 'Có người vừa bình luận về tranh sơn dầu của bạn', 'Thông báo', '2024-03-13 14:20:00', 'ND2', 'SP13'),
('TB15', 'Đấu giá sắp kết thúc', 'Sách Harry Potter của bạn sắp kết thúc đấu giá', 'Cảnh báo', '2024-03-23 15:30:00', 'ND4', 'SP14'),
('TB2', 'Sản phẩm yêu thích', 'iPhone 15 Pro Max sắp kết thúc đấu giá', 'Cảnh báo', '2024-03-10 19:30:00', 'ND3', 'SP1'),
('TB3', 'Đấu giá thành công', 'Bạn đã thắng phiên đấu giá MacBook Air M2', 'Thắng cuộc', '2024-03-11 18:05:00', 'ND3', 'SP2'),
('TB4', 'Có người ra giá cao hơn', 'Có người vừa ra giá cao hơn cho đồng hồ Rolex', 'Cập nhật', '2024-03-04 10:35:00', 'ND3', 'SP3'),
('TB5', 'Đấu giá sắp kết thúc', 'Máy ảnh Sony A7III của bạn sắp kết thúc đấu giá', 'Cảnh báo', '2024-03-13 15:30:00', 'ND4', 'SP4'),
('TB6', 'Đấu giá thành công', 'Bạn đã thắng phiên đấu giá Samsung S24', 'Thắng cuộc', '2024-03-14 15:05:00', 'ND7', 'SP5'),
('TB7', 'Có người theo dõi', 'Sản phẩm Dell XPS 13 của bạn có người theo dõi', 'Thông báo', '2024-03-07 11:20:00', 'ND8', 'SP6'),
('TB8', 'Đấu giá thành công', 'Bạn đã thắng phiên đấu giá đồng hồ Casio', 'Thắng cuộc', '2024-03-16 20:05:00', 'ND9', 'SP7'),
('TB9', 'Sản phẩm được yêu thích', 'Canon EOS R5 của bạn được thêm vào danh sách yêu thích', 'Thông báo', '2024-03-08 09:15:00', 'ND12', 'SP8');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chi_tiet_hoa_don`
--
ALTER TABLE `chi_tiet_hoa_don`
  ADD KEY `SoHD` (`SoHD`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `danh_muc`
--
ALTER TABLE `danh_muc`
  ADD PRIMARY KEY (`MaDM`);

--
-- Chỉ mục cho bảng `danh_muc_con`
--
ALTER TABLE `danh_muc_con`
  ADD PRIMARY KEY (`MaDMCon`),
  ADD KEY `MaDM` (`MaDM`);

--
-- Chỉ mục cho bảng `danh_sach_hinh_anh`
--
ALTER TABLE `danh_sach_hinh_anh`
  ADD PRIMARY KEY (`MaDSHA`,`hinhanh`);

--
-- Chỉ mục cho bảng `danh_sach_yeu_thich`
--
ALTER TABLE `danh_sach_yeu_thich`
  ADD PRIMARY KEY (`MaDS`),
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `gio_hang`
--
ALTER TABLE `gio_hang`
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `hoa_don`
--
ALTER TABLE `hoa_don`
  ADD PRIMARY KEY (`SoHD`),
  ADD KEY `MaND` (`MaND`);

--
-- Chỉ mục cho bảng `lich_su_dau_gia`
--
ALTER TABLE `lich_su_dau_gia`
  ADD PRIMARY KEY (`MaLS`),
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`MaND`);

--
-- Chỉ mục cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`MaSP`),
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaDM` (`MaDM`),
  ADD KEY `MaDSHA` (`MaDSHA`),
  ADD KEY `MaDMCon` (`MaDMCon`);

--
-- Chỉ mục cho bảng `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`MaSL`);

--
-- Chỉ mục cho bảng `thong_bao`
--
ALTER TABLE `thong_bao`
  ADD PRIMARY KEY (`MaTB`),
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chi_tiet_hoa_don`
--
ALTER TABLE `chi_tiet_hoa_don`
  ADD CONSTRAINT `chi_tiet_hoa_don_ibfk_1` FOREIGN KEY (`SoHD`) REFERENCES `hoa_don` (`SoHD`) ON UPDATE CASCADE,
  ADD CONSTRAINT `chi_tiet_hoa_don_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `danh_sach_hinh_anh`
--
ALTER TABLE `danh_sach_hinh_anh`
  ADD CONSTRAINT `danh_sach_hinh_anh_ibfk_1` FOREIGN KEY (`MaDSHA`) REFERENCES `san_pham` (`MaDSHA`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `danh_sach_yeu_thich`
--
ALTER TABLE `danh_sach_yeu_thich`
  ADD CONSTRAINT `danh_sach_yeu_thich_ibfk_1` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`) ON UPDATE CASCADE,
  ADD CONSTRAINT `danh_sach_yeu_thich_ibfk_2` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `gio_hang`
--
ALTER TABLE `gio_hang`
  ADD CONSTRAINT `gio_hang_ibfk_1` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gio_hang_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `hoa_don`
--
ALTER TABLE `hoa_don`
  ADD CONSTRAINT `hoa_don_ibfk_1` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `lich_su_dau_gia`
--
ALTER TABLE `lich_su_dau_gia`
  ADD CONSTRAINT `lich_su_dau_gia_ibfk_1` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE,
  ADD CONSTRAINT `lich_su_dau_gia_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD CONSTRAINT `san_pham_ibfk_1` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE,
  ADD CONSTRAINT `san_pham_ibfk_2` FOREIGN KEY (`MaDM`) REFERENCES `danh_muc` (`MaDM`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `thong_bao`
--
ALTER TABLE `thong_bao`
  ADD CONSTRAINT `thong_bao_ibfk_1` FOREIGN KEY (`MaND`) REFERENCES `nguoi_dung` (`MaND`) ON UPDATE CASCADE,
  ADD CONSTRAINT `thong_bao_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
