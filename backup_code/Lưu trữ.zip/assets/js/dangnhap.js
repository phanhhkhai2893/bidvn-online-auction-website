/* jshint esversion: 6 */ 
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const modal = document.getElementById('auth-modal');
const closeModal = document.getElementById('close-modal');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const popupbanner = document.getElementById('popup-banner');
const popupimg = document.getElementById('popup-banner-img');
const closePopup = document.getElementById('close-popup');

// 2. Hàm mở Modal và hiển thị Form tương ứng
function openModal(formType) {
  'use strict';
    modal.classList.remove('hidden');

    if (formType === 'login') {
        // Hiển thị Form Đăng nhập
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
    } else if (formType === 'register') {
        // Hiển thị Form Đăng ký
        registerForm.classList.remove('hidden');
        loginForm.classList.add('hidden');
    }
}

// 3. Hàm đóng Modal
function closeAuthModal() {
  'use strict';
    modal.classList.add('hidden');
}

// 4. Gắn trình lắng nghe sự kiện (Event Listeners)

// Khi click Đăng nhập
loginBtn.addEventListener('click', () => {
  'use strict';
    openModal('login');
});

// Khi click Đăng ký
registerBtn.addEventListener('click', () => {
  'use strict';
    openModal('register');
});

// Khi click nút đóng (x)
closeModal.addEventListener('click', closeAuthModal);

// Khi click ra ngoài Modal, đóng Modal
window.addEventListener('click', (event) => {
  'use strict';
    if (event.target === modal) {
        closeAuthModal();
    }
});

// Khi click nút đóng (x)
closePopup.addEventListener('click', closePopupBanner);
// 3. Hàm đóng Modal
function closePopupBanner() {
  'use strict';
	popupimg.classList.add('hidden');
    popupbanner.classList.add('hidden');
}
