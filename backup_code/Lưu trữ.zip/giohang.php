<?PHP
  session_start();
  include('assets/php/database/db_connection.php');
  $kn = new db_connection();
//				$_SESSION = array();
//
//				if (ini_get("session.use_cookies")) {
//					$params = session_get_cookie_params();
//					setcookie(session_name(), '', time() - 42000,
//						$params["path"], $params["domain"],
//						$params["secure"], $params["httponly"]
//					);
//				}
//
//				session_destroy();
	unset($_SESSION['SignInError']);
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/giohang.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="icon" href="assets/imgs/logo/bidvn.ico" type="image/x-icon">
</head>

<body>
  <!--  ==========  HEADER  ==========  -->
  <?PHP include('assets/php/sections/header.php') ?>
	
  
  <!--  ==========  BODY  ==========  -->
  <div id="body">
	<div class="cart-ui-wrapper">
		<div class="cart-ui-header">
			<div class="container">
				<div class="cart-ui-logo-area">
					<h1 class="cart-ui-title">Giỏ Hàng</h1>
				</div>
			</div>
		</div>

		<div class="cart-ui-container">
			<div class="cart-ui-table-header">
				<div class="cart-ui-col cart-ui-col-product">Sản Phẩm</div>
				<div class="cart-ui-col cart-ui-col-price-unit">Đơn Giá</div>
				<div class="cart-ui-col cart-ui-col-quantity">Số Lượng</div>
				<div class="cart-ui-col cart-ui-col-total-price">Số Tiền</div>
				<div class="cart-ui-col cart-ui-col-action">Thao Tác</div>
			</div>
			
			<?PHP
				if (isset($_SESSION['tennd']))
					$tennd = $_SESSION['tennd'];
				if (isset($_SESSION['role']))
					$role_real = $_SESSION['role'];
				if (isset($_SESSION['mand']))
					$MaND_real = $_SESSION['mand'];
					
                $query = "
				SELECT
					gh.MaND,
					gh.MaSP,
					sp.MaDSHA,
					sp.tensp,
					dmc.tendm,
					MIN(dsha.hinhanh) AS hinhanh_dai_dien,
					sp.gia_hientai, 
					(gh.soluong * gh.thanhtien) as 'tongtien',
					gh.soluong, 
					gh.thanhtien
				FROM
					gio_hang gh
				LEFT JOIN -- Sử dụng LEFT JOIN để giữ lại tất cả các dòng từ gio_hang
					san_pham sp ON gh.MaSP = sp.MaSP
				LEFT JOIN -- Sử dụng LEFT JOIN
					danh_sach_hinh_anh dsha ON dsha.MaDSHA = sp.MaDSHA
				LEFT JOIN -- Sử dụng LEFT JOIN
					danh_muc_con dmc ON sp.MaDMCon = dmc.MaDMCon
				WHERE
					gh.MaND = 'ND3'
				GROUP BY 
					gh.MaSP, sp.tensp, dmc.tendm, sp.gia_hientai, gh.MaND
				ORDER BY
					gh.MaSP;";
                $result = mysqli_query($kn->con, $query)
                  or die("Lỗi DTB");
                while ($row = mysqli_fetch_array($result))
				{
					$maspGH = $row['MaSP'];
			?>
					<div data-maspGH="<?PHP echo $row['MaSP'] ?>" class="cart-ui-item">
						<div class="cart-ui-col cart-ui-col-product">
							<div class="cart-ui-product-info">
								<img src="assets/imgs/product/<?PHP echo $row['MaDSHA'] ?>/<?PHP echo $row['hinhanh_dai_dien'] ?>" alt="<?PHP echo $row['tensp'] ?>" class="cart-ui-product-img">
								<div class="cart-ui-details">
									<p class="cart-ui-product-name"><?PHP echo $row['tensp'] ?></p>
									<p class="cart-ui-variant-info">Phân Loại Hàng: <?PHP echo $row['tendm'] ?></p>
								</div>
							</div>
						</div>
						<div class="cart-ui-col cart-ui-col-price-unit">
							<?PHP echo number_format($row['thanhtien'], 0, '', '.') . "đ"; ?>
						</div>
						
						<div class="cart-ui-col cart-ui-col-quantity cart-ui-quantity-display">
							<?PHP echo $row['soluong'] ?>
						</div>
						
						<div class="cart-ui-col cart-ui-col-total-price">
							<?PHP echo number_format($row['tongtien'], 0, '', '.') . "đ" ?>
						</div>
						
						<form method="post" class="cart-ui-col cart-ui-col-action">
							<button type="submit" name="xoagh" class="cart-ui-delete-btn" value="<?PHP echo $maspGH; ?>">Xóa</button>
						</form>
					</div>
			<?PHP
				}
			if (isset($_POST['xoagh']))
			{
				$maspGH = $_POST['xoagh'];
				$queryXoaGH = "DELETE FROM gio_hang WHERE MaND = '$MaND_real' AND MaSP = '$maspGH'";
//				echo $queryXoaGH;
				$result = mysqli_query($kn -> con, $queryXoaGH)
				  or die("Lỗi DTB");

				if ($result) {
					echo "<meta http-equiv='refresh' content='0; url=giohang.php' />";
				} 
				else {
					echo "Lỗi cập nhật dữ liệu: " . mysqli_error($kn -> con);
				}
			}
            ?>
		</div>

		<div class="cart-ui-summary-sticky">
			<div class="container">
				<div class="cart-ui-summary-left">
					<?PHP
						$query1 = "SELECT COUNT(MaSP) as 'tongsp'
									FROM gio_hang
									WHERE MaND = '$MaND_real'";
						$result1 = mysqli_query($kn->con, $query1)
						  or die("Lỗi DTB");
						$row1 = mysqli_fetch_assoc($result1);
					
						$query2 = "SELECT sum(soluong * thanhtien) as 'tt'
									FROM gio_hang
									WHERE MaND = '$MaND_real'";
						$result2 = mysqli_query($kn->con, $query2)
						  or die("Lỗi DTB");
						$row2 = mysqli_fetch_assoc($result2);
					
						
					?>
				</div>

				<div class="cart-ui-summary-right">
					<div class="cart-ui-total-section">
						<span class="cart-ui-total-text">Tổng cộng (<?PHP echo $row1['tongsp'] ?> sản phẩm):</span>
						<span class="cart-ui-total-price-final">
							<?PHP echo number_format($row2['tt'], 0, '', '.') . "đ" ?>
						</span>
	
						<?PHP
							$thanhtien = number_format($row2['tt'], 0, '', '.') . "đ";
						?>
						
						<a href="thanhtoan_index.php?tt=<?PHP echo $thanhtien; ?>" class="cart-ui-checkout-btn">MUA HÀNG</a>
					</div>
				</div>
			</div>
		</div>
    </div>
  </div>
	
  <!--  ==========  FOOTER  ==========  -->
  <?PHP include('assets/php/sections/footer.php') ?>
	<div id="toast-ui-container" class="toast-ui-container">
    </div>
	
  <!--  ==========  JS  ==========  -->

</body>
</html>